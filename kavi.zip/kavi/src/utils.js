export const defaultSourceState = { isLoading: true };
